<h5 class="my-3">Quote Example:</h5>
<blockquote class="blockquote m-lg-5 py-3 pl-4 px-lg-5">
    <p class="mb-2">You might not think that programmers are artists, but programming is an extremely creative profession. It's logic-based creativity.</p>
    <footer class="blockquote-footer">John Romero</footer>
</blockquote>